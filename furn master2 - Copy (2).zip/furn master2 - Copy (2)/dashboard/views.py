from django.shortcuts import render

def dashboard_home(request):
    return render(request, 'dashboard/pages/home.html')

def btns(request):
    return render(request, 'dashboard/includes/buttons.html')