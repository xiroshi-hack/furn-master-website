from django.urls import path
from . import views
from dashboard.views import *

urlpatterns = [
    path('', views.dashboard_home),
    path('/btns/', btns)
]